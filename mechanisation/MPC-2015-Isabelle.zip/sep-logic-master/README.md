# sep-logic
A verification tool based on separation logic in Isabelle/HOL
